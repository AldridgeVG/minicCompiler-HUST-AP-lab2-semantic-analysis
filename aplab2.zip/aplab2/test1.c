int glb1,glb2;
float glb3,glb4;
char glb5;
int test(int a)
{
  int a1,a2=1;
  a1=1.1;
  a1=a1/a2;
  if(a1==1)
  {
    a2=3;
    break;
  }//gkhgkhghgkh
  else
  {
    int j;
    j=a2;
    a2++;
  }
  return 1.2;
}
int main()
{
  int a1,a2=1;
  int a3[30];
  test();
  test(3);
  while(a2>0)
  {
    int i=a1;
    a1=3;
    break;
  }
  return 1;
}